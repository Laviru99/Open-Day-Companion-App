package com.example.myqrscanner;

import com.journeyapps.barcodescanner.CaptureActivity;

public class StartScan extends CaptureActivity {
}
